import React from "react"; 

const Homepage=()=>{
return <h1>Welcome to Homepage</h1>
}

export default Homepage;